<?php
// Heading
$_['heading_title'] = 'Price Slider by Smartiapps';

// Text
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit Price Slider Module';
$_['text_success'] = 'Success: You have modified Price Slider module!';
$_['text_setting'] = 'Price Slider Setting';
$_['text_Price'] = 'Price Filter';
$_['text_price_limits'] = '0-300';

// Entry 

$_['entry_heading'] = 'Title';
$_['entry_status_price'] = 'Status';
$_['entry_Price_filter'] = 'Price Filter';
$_['entry_price_range'] = 'Price Range';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Price Slider module!';
$_['error_required'] = 'This field is required';

  
