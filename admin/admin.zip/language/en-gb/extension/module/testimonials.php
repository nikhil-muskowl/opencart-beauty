<?php
// Heading
$_['heading_title']    = 'Testimonials';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Testimonials module!';
$_['text_edit']        = 'Edit Testimonials Module';

// Entry
$_['entry_head']     = 'Widget Heading';
$_['entry_image']     = 'Widget background image';

$_['entry_font_clr']     = 'Widget Font color';
$_['entry_bgclr']     = 'Widget background color';
$_['entry_status']     = 'Status';
$_['entry_author_size']     = 'Author image size';

// Errorentry_head
$_['error_permission'] = 'Warning: You do not have permission to modify Testimonials module!';