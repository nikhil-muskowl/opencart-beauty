<?php

// Heading
$_['heading_title'] = 'Brand Filter';

// Text
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit Brand Filter Module';
$_['text_success'] = 'Success: You have modified Brand Filter module!';
$_['text_setting'] = 'Brand Filter Setting';
$_['text_Price'] = 'Brand Filter';

// Entry 

$_['entry_heading'] = 'Title';
$_['entry_status_price'] = 'Status';
$_['entry_brand_filter'] = 'Brand Filter';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Brand Filter module!';
$_['error_required'] = 'This field is required';


